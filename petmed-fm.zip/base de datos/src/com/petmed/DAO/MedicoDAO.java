/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.petmed.DAO;

import com.petmed.models.DataConexion;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Lost Legion
 */
public class MedicoDAO {
    
    public void ingresarMedico(){}
    public void modificarMedico(){}
    public void eliminarMedico(){}
    
    public void insert(){}
    public void update(){}
    public void delete(){}
    
    public int buscarMedico(String nombre){
        String seleccion = "{call find_medico('" + nombre +"')}";
           ResultSet resul = DataConexion.ejecutarProcedureSelect(seleccion);
            try {
                if(resul.next()){
                    return resul.getInt(1);
                }
            } catch (SQLException ex) {
                ex.printStackTrace();           
            }
           return 0; 
    }
}
