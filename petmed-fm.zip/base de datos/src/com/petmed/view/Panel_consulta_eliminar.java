/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.petmed.view;

import com.petmed.DAO.ClienteDAO;
import com.petmed.DAO.ConsultaDAO;
import com.petmed.DAO.MascotaDAO;
import com.petmed.DAO.MedicoDAO;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Lost Legion
 */
public class Panel_consulta_eliminar {
      JTextField txt_cliente; 
      JTextField txt_mascota;
      JTextField txt_medico;
      
    public Panel_consulta_eliminar(){
    
      txt_cliente = new JTextField(5);
      txt_mascota = new JTextField(5);
      txt_medico = new JTextField(5);
      JPanel myPanel = new JPanel();
      myPanel.add(new JLabel("Cliente:"));
      myPanel.add(txt_cliente);
      myPanel.add(Box.createHorizontalStrut(15));       
      myPanel.add(new JLabel("Mascota:"));
      myPanel.add(txt_mascota);      
      myPanel.add(Box.createHorizontalStrut(15));
      myPanel.add(new JLabel("Medico:"));
      myPanel.add(txt_medico);

      int result = JOptionPane.showConfirmDialog(null, myPanel, 
      "Esta seguro de eliminar esta consulta de la base de datos", JOptionPane.OK_CANCEL_OPTION);
      
      if (result == JOptionPane.OK_OPTION) {
         
          try{
          int cliente_id = new ClienteDAO().buscarCliente(txt_cliente.getText());
          int mascota_id = new MascotaDAO().buscarMascota(txt_mascota.getText(), cliente_id);
          int medico_id = new MedicoDAO().buscarMedico(txt_medico.getText());
          
              SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
              Date dt = new Date();
              String date = sdf.format(dt);
              java.sql.Date currentTime = new java.sql.Date(sdf.parse(date).getTime());

              int aux_consul = new ConsultaDAO().eliminarConsulta(currentTime, medico_id, mascota_id);
              new Panel_consulta().borrarCampos();

              if(aux_consul>0){
                  JOptionPane.showMessageDialog(null, "Consulta eliminada exitosamente");
              }else{
                  JOptionPane.showMessageDialog(null, "Erro de eliminacion");
              }
          }catch(Exception ex){
              
          }
          
      }

   }
}
